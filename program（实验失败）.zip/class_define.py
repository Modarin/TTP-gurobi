#!/usr/bin/env python
# -*- coding:utf-8 -*-
#@Time  : 2021/5/24 14:56
#@Author: Pengli Mo
#@File  : class_define.py

class Data:
    def __init__(self):
        # self.travel_up=[]
        self.travel=[]
        # self.E_tr_up = []
        self.E_tr = []
        # self.E_rg_up = []
        self.E_rg = []
        self.passenger={}
        self.timetable=[]
        self.num_K=0
        # self.timetable_dn=[]